from typing import Optional, List
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlmodel import Field, SQLModel, Session, create_engine, select

DATABASE_URL = "sqlite:///./app.db"
engine = create_engine(DATABASE_URL, echo=False, connect_args={"check_same_thread": False})

class Task(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: Optional[str] = None
    done: bool = False

class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    done: Optional[bool] = None

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

app = FastAPI(title="Task Manager API")

@app.on_event("startup")
def on_startup():
    create_db_and_tables()

@app.post("/tasks/", response_model=Task, status_code=201)
def create_task(task: TaskCreate):
    with Session(engine) as session:
        db_task = Task(title=task.title, description=task.description)
        session.add(db_task)
        session.commit()
        session.refresh(db_task)
        return db_task

@app.get("/tasks/", response_model=List[Task])
def list_tasks(skip: int = 0, limit: int = 100):
    with Session(engine) as session:
        statement = select(Task).offset(skip).limit(limit)
        results = session.exec(statement).all()
        return results

@app.get("/tasks/{task_id}", response_model=Task)
def get_task(task_id: int):
    with Session(engine) as session:
        task = session.get(Task, task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        return task

@app.put("/tasks/{task_id}", response_model=Task)
def update_task(task_id: int, task_update: TaskUpdate):
    with Session(engine) as session:
        task = session.get(Task, task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        task.title = task_update.title or task.title
        task.description = task_update.description if task_update.description is not None else task.description
        task.done = task_update.done if task_update.done is not None else task.done
        session.add(task)
        session.commit()
        session.refresh(task)
        return task

@app.delete("/tasks/{task_id}", status_code=204)
def delete_task(task_id: int):
    with Session(engine) as session:
        task = session.get(Task, task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        session.delete(task)
        session.commit()
        return